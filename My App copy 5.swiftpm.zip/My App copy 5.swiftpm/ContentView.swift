import SwiftUI

struct ContentView: View {
    @State private var combo = [Int.random(in: 0..<40),
                                Int.random(in: 0..<40),
                                Int.random(in: 0..<40)]
    
    @State private var dialPosition = 0
    @State private var angle: CGFloat = 0
    @State private var step = 0
    @State private var passedFirst = false
    @State private var unlocked = false
    @State private var previousPosition = 0
    
    var body: some View {
        VStack(spacing: 50) {
            ShareLink(item: /*@START_MENU_TOKEN@*/URL(string: "https://developer.apple.com/xcode/swiftui")!/*@END_MENU_TOKEN@*/)
            Text("Locker Combo Simulator")
                .font(.largeTitle)
            
            ZStack {
                Circle()
                    .stroke(Color.black, lineWidth: 4)
                    .frame(width: 200, height: 200)
                
                ForEach(0..<40) { i in
                    let rad = Angle(degrees: Double(i)/40*360).radians
                    Text("\(i)")
                        .font(.system(size: 10))
                        .position(
                            x: 100 + 80 * cos(CGFloat(rad - .pi/2)),
                            y: 100 + 80 * sin(CGFloat(rad - .pi/2))
                        )
                }
                
                Rectangle()
                    .fill(Color.red)
                    .frame(width: 4, height: 20)
                    .offset(y: -90)
                    .rotationEffect(.degrees(angle))
            }
            .frame(width: 200, height: 200)
            .gesture(
                DragGesture()
                    .onChanged { value in
                        let dx = value.location.x - 100
                        let dy = value.location.y - 100
                        let radians = atan2(dy, dx)
                        var newAngle = radians * 180 / .pi - 90
                        if newAngle < 0 { newAngle += 360 }
                        let newPos = Int((newAngle / 360) * 40) % 40
                        handleRotation(newPos)
                    }
            )
            
            Text("Dial: \(dialPosition)")
                .font(.headline)
            
            HStack(spacing: 20) {
                Button("↺ -1") { stepDial(-1) }
                    .padding()
                Button("+1 ↻") { stepDial(1) }
                    .padding()
            }
            
            HStack(spacing: 20) {
                Button("Open") { unlocked = (step == 3) }
                    .padding()
                Button("Reset") { resetLock() }
                    .padding()
            }
            
            Text("Combo: \(combo[0]) - \(combo[1]) - \(combo[2])")
                .font(.headline)
                .foregroundColor(.black)
            
            if unlocked {
                Text("✅ Unlocked!")
                    .font(.largeTitle)
                    .foregroundColor(.green)
            } else {
                Text("🔒 Locked")
                    .foregroundColor(.red)
            }
            
            
        }
        .padding()
    }
    
    func stepDial(_ delta: Int) {
        let newPos = (dialPosition + delta + 40) % 40
        withAnimation(.easeInOut(duration: 0.1)) {
            angle = CGFloat(newPos) / 40 * 360
        }
        handleRotation(newPos)
    }
    
    func handleRotation(_ newPos: Int) {
        let diff = (newPos - previousPosition + 40) % 40
        let clockwise = diff < 20 && diff != 0
        let ccw = !clockwise && diff != 0
        
        switch step {
        case 0: // CW to first number
            if clockwise && newPos == combo[0] {
                step = 1
                passedFirst = false
            }
        case 1: // CCW, pass first once, then stop at second
            if ccw {
                if !passedFirst && newPos == combo[0] {
                    passedFirst = true
                }
                if passedFirst && newPos == combo[1] {
                    step = 2
                }
            }
        case 2: // CW to third
            if clockwise && newPos == combo[2] {
                step = 3
            }
        default: break
        }
        
        dialPosition = newPos
        previousPosition = newPos
        
        withAnimation(.easeInOut(duration: 0.1)) {
            angle = CGFloat(dialPosition) / 40 * 360
        }
    }
    
    func resetLock() {
        dialPosition = 0
        previousPosition = 0
        angle = 0
        step = 0
        passedFirst = false
        unlocked = false
        combo = [Int.random(in: 0..<40),
                 Int.random(in: 0..<40),
                 Int.random(in: 0..<40)]
    }
}

